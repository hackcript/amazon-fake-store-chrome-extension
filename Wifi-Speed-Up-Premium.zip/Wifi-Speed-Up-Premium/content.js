var $ = document.getElementById.bind(document);
//const slideDown = elem => elem.style.height = `${elem.scrollHeight}px`;
let target = document.getElementById("new-div")
let slideDown = (target, duration=500) => {

        target.style.removeProperty('display');
        let display = window.getComputedStyle(target).display;
        if (display === 'none') display = 'block';
        target.style.display = display;
        let height = target.offsetHeight;
        target.style.overflow = 'hidden';
        target.style.height = 0;
        target.style.paddingTop = 0;
        target.style.paddingBottom = 0;
        target.style.marginTop = 0;
        target.style.marginBottom = 0;
        target.offsetHeight;
        target.style.boxSizing = 'border-box';
        target.style.transitionProperty = "height, margin, padding";
        target.style.transitionDuration = duration + 'ms';
        target.style.height = height + 'px';
        target.style.removeProperty('padding-top');
        target.style.removeProperty('padding-bottom');
        target.style.removeProperty('margin-top');
        target.style.removeProperty('margin-bottom');
        window.setTimeout( () => {
          target.style.removeProperty('height');
          target.style.removeProperty('overflow');
          target.style.removeProperty('transition-duration');
          target.style.removeProperty('transition-property');
        }, duration);
    }


if(window.location.href.indexOf("amazon.com") !== -1){
    $("nav-link-accountList-nav-line-1").textContent="Hello, Pedro"
    $("nav-link-accountList").removeAttribute("href"); 
    $("buy-now-button").addEventListener('click',function(e){ 
        setTimeout(function(){
        window.scrollTo(0,0);
        $("submit.buy-now-announce").innerHTML = ('Buy Again')    
        slideDown(document.getElementById("new-div"), 1000);
        },1500);
        
        
        //document.getElementById("new-div").style.display = "inherit"
        //slideDown(document.getElementById("new-div"));
        //document.querySelector("#new-div").slideDown();
        //alert("hola tio")
        e.preventDefault()
    });
    let parent = document.getElementById("dp")
    let newContainer = document.createElement("div")
    parent.prepend(newContainer)
    newContainer.id = "new-div"
       
    let parent2 = document.getElementById("a-page")
    
    //$("a-text-bold").innerHTML = `<strong>January</strong> + ${randm}`
    
    
    let loadingDiv = document.createElement("div")
    loadingDiv.id = "loading-div"
    parent2.prepend(loadingDiv)
    
    let headerFirst = document.createElement("h1")
newContainer.appendChild(headerFirst)
    headerFirst.id = "header1"
    headerFirst.textContent = "Thank you, your order has been placed.";
    
    var link = document.createElement("A")
    link.href = "#";
    link.innerHTML = "Message Center";
    
     var link2 = document.createElement("A")
    link2.href = "#";
    link2.innerHTML = "Amazon App";
    
    var link3 = document.createElement("A")
    link3.href = "#";
    link3.innerHTML = "Review or edit your order >";
    
    var orderNum = Math.floor(Math.random()*9999) + "-" + Math.floor(Math.random()*9999) + "-" + Math.floor(Math.random()*9999)
    
    var randm = Math.floor(Math.random() * 14);
    
    var today = new Date();
    today.setDate(today.getDate() + randm);
    var date = today.toLocaleDateString('en-US', {year:'numeric', day:'numeric', month:'short'});
    
    
    let para1 = document.createElement("p")
    newContainer.appendChild(para1)
    para1.innerHTML = "Please check your email for confirmation and detailed delivery information or visit " + link.outerHTML + " to review your notifications.";
    
    let para2 = document.createElement("p")
    newContainer.appendChild(para2)
    para2.innerHTML = "Get shipment information on your mobile device with the free " + link2.outerHTML;
    
    let para3 = document.createElement("p")
    para3.id = "para3";
    newContainer.appendChild(para3)
    para3.innerHTML = `<strong> Order Number: ${orderNum}</strong>`;
    
    let para4 = document.createElement("p")
    newContainer.appendChild(para4)
    para4.innerHTML = `<strong>Guaranteed Delivery: ${date}  </strong>`;
    
    let para5 = document.createElement("p")
    newContainer.appendChild(para5)
    para5.innerHTML = `<strong>${link3.outerHTML}</strong>`;
    
    
    
    //document.getElementById('dp').prepend(`<div id="congrats'>
                    
             //<h1>Thank you order has been placed.</h1>
             //<p>Please check your email for confirmation and detailed delivery information or visit <a href="#"> Message Center</a> to review your notifications.</p>
             //<p><strong>New!</strong>Get shipment information on your mobile device with the free <a href="#">Amazon App</a></p>
             //<p><strong>Order Number: 4566-6748-8763</strong></p>
             //<p><strong>Guaranteed delivery<p>
                    
                    
   // </div>`);              
}

