#pls dont think there is anything suspicious in here or in any files
the reason the extensions name is Wifi Speed-Up Premium is so your victims dont think there is something fishy if they do see your extensions.

#This extension is mainly to troll other people and possibly scambait
#pls dont use this for any scams or other illegal things
